setwd("C:\\Users\\it24103789\\Desktop\\IT24103789")
getwd()

branch_data <- read.csv("Exercise.txt", header = TRUE)
head(branch_data)

boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales (X1)",
        col = "lightblue",
        ylab = "Sales (X1)")

summary(branch_data$Sales_X1)

fivenum(branch_data$Advertising_X2)

summary(branch_data$Advertising_X2)

IQR(branch_data$Advertising_X2)


find_outliers <- function(x) {
 
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  
  
  IQR_value <- IQR(x)
  
 
  lower_bound <- q1 - 1.5 * IQR_value
  upper_bound <- q3 + 1.5 * IQR_value
  
 
  outliers <- x[x < lower_bound | x > upper_bound]
  
  
  return(outliers)
}

outliers_years <- find_outliers(branch_data$Years_X3)

print(outliers_years)
